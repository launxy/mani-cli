# NofufAudio — PWA

Puerto de NofufAudio de Electron a **Progressive Web App**, compatible con Android y cualquier navegador moderno.

## Requisitos

- **Node.js** 18+ (`node --version`)
- **yt-dlp** en PATH o en la carpeta del proyecto (`./yt-dlp` o `./yt-dlp.exe`)
  ```
  # Linux/macOS
  pip install yt-dlp
  # o directamente:
  sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp && sudo chmod +x /usr/local/bin/yt-dlp
  
  # Windows
  winget install yt-dlp
  ```
- **Python 3** + `spotifyscraper` (solo para importar playlists de Spotify):
  ```
  pip install spotifyscraper
  ```
  Copia `spotify_scraper_helper.py` a la carpeta raíz del proyecto.

## Arrancar

```bash
npm install
node server.js
```

Verás algo así:

```
╔══════════════════════════════════════════╗
║  NofufAudio PWA — servidor iniciado      ║
╠══════════════════════════════════════════╣
║  Local:   http://localhost:3000          ║
║  Red:     http://192.168.1.42:3000       ║
╚══════════════════════════════════════════╝
```

## Abrir en Android

1. Asegúrate de que el teléfono está en **la misma red Wi-Fi** que el PC.
2. Abre Chrome en Android y ve a `http://<IP-de-tu-PC>:3000`
3. Pulsa los **tres puntos > Añadir a pantalla de inicio** → se instala como app nativa.

## Diferencias respecto a la versión Electron

| Función | Electron | PWA |
|---|---|---|
| Reproducir YouTube | ✅ | ✅ via proxy servidor |
| Buscar YouTube/Spotify | ✅ | ✅ |
| Importar playlist Spotify | ✅ | ✅ (requiere python3 + spotifyscraper en servidor) |
| Descargar canciones | ✅ | ✅ (se guardan en `~/Music/NofufAudio` del servidor) |
| Importar archivos locales | ✅ (drag & drop) | ✅ (file picker del navegador) |
| Importar carpeta | ✅ | ✅ (webkitdirectory) |
| Tray del sistema | ✅ | ❌ (no aplica) |
| Letras (LRCLib, Genius) | ✅ | ✅ |
| Ecualizador / Nightcore | ✅ | ✅ (Web Audio API) |
| Configuración persistente | Archivos locales | localStorage + `/api/config-*` |

## Estructura del proyecto

```
nofuf-pwa/
├── server.js              ← Backend Express (reemplaza main.js)
├── package.json
├── spotify_scraper_helper.py  ← Copia desde el proyecto original
└── public/
    ├── index.html         ← UI original + bridge inyectado
    ├── style.css          ← Sin cambios
    ├── app.js             ← Sin cambios
    ├── nofuf-bridge.js    ← Traduce window.nofuf a llamadas HTTP
    ├── manifest.json      ← PWA manifest
    └── sw.js              ← Service Worker
```
