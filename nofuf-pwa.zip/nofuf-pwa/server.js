/* ═══════════════════════════════════════════════
   NOFUFAUDIO — server.js (PWA backend)
   Reemplaza main.js de Electron.
   Uso: node server.js
   Luego abre http://localhost:3000 en el navegador / Android.
═══════════════════════════════════════════════ */

const express  = require('express');
const path     = require('path');
const fs       = require('fs');
const os       = require('os');
const https    = require('https');
const http     = require('http');
const { spawn } = require('child_process');
const multer   = require('multer');

const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true }));

/* ─── CORS (para desarrollo local) ─────────────── */
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

/* ─── Servir los archivos estáticos del frontend ─ */
app.use(express.static(path.join(__dirname, 'public')));

/* ══════════════════════════════════════════════════
   STREAM PROXY  — reemplaza el proxy local de Electron
   GET /stream?url=<encoded>
══════════════════════════════════════════════════ */
app.get('/stream', (req, res) => {
  const target = req.query.url;
  if (!target || !target.startsWith('https://')) {
    return res.status(400).send('Bad request');
  }
  try {
    const parsed = new URL(target);
    const options = {
      hostname: parsed.hostname,
      path: parsed.pathname + parsed.search,
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Origin': 'https://www.youtube.com',
        'Referer': 'https://www.youtube.com/',
      },
    };
    if (req.headers['range']) options.headers['Range'] = req.headers['range'];

    const proxyReq = https.request(options, (proxyRes) => {
      const status = proxyRes.statusCode;
      const headers = {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': proxyRes.headers['content-type'] || 'audio/mp4',
      };
      if (proxyRes.headers['content-length']) headers['Content-Length'] = proxyRes.headers['content-length'];
      if (proxyRes.headers['content-range'])  headers['Content-Range']  = proxyRes.headers['content-range'];
      if (proxyRes.headers['accept-ranges'])  headers['Accept-Ranges']  = proxyRes.headers['accept-ranges'];
      res.writeHead(status === 206 ? 206 : 200, headers);
      proxyRes.pipe(res);
    });
    proxyReq.on('error', (e) => {
      console.error('[proxy] error:', e.message);
      if (!res.headersSent) res.status(502).end();
    });
    proxyReq.end();
  } catch (e) {
    console.error('[proxy] exception:', e.message);
    if (!res.headersSent) res.status(500).end();
  }
});

/* ══════════════════════════════════════════════════
   CONFIG — carpeta en home del usuario
══════════════════════════════════════════════════ */
function getConfigDir() {
  const dir = path.join(os.homedir(), 'nofufaudioConfigs');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

app.get('/api/config-dir', (req, res) => res.json({ dir: getConfigDir() }));

app.get('/api/config-read/:name', (req, res) => {
  try {
    const p = path.join(getConfigDir(), req.params.name);
    if (!fs.existsSync(p)) return res.json({ content: null });
    return res.json({ content: fs.readFileSync(p, 'utf-8') });
  } catch (e) { res.json({ content: null }); }
});

app.post('/api/config-write', (req, res) => {
  try {
    const { name, content } = req.body;
    const p = path.join(getConfigDir(), name);
    fs.writeFileSync(p, content, 'utf-8');
    res.json({ ok: true, path: p });
  } catch (e) { res.json({ ok: false, error: e.message }); }
});

/* ══════════════════════════════════════════════════
   SYSTEM FONTS
══════════════════════════════════════════════════ */
app.get('/api/system-fonts', (req, res) => {
  const platform = process.platform;
  let cmd, args;
  if (platform === 'win32') {
    cmd = 'powershell';
    args = ['-NoProfile', '-NonInteractive', '-Command',
      `(Get-ItemProperty 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts').PSObject.Properties | ForEach-Object { $_.Name -replace ' \\(.*\\)','' } | Sort-Object -Unique`];
  } else if (platform === 'darwin') {
    cmd = 'system_profiler'; args = ['SPFontsDataType', '-json'];
  } else {
    cmd = 'fc-list'; args = [':', 'family'];
  }
  const proc = spawn(cmd, args, { timeout: 10000 });
  const chunks = [];
  proc.stdout.on('data', c => chunks.push(c));
  proc.on('close', () => {
    try {
      const out = Buffer.concat(chunks).toString('utf-8');
      let fonts = [];
      if (platform === 'linux') {
        fonts = out.split('\n').flatMap(l => l.split(',')).map(l => l.trim()).filter(l => l.length > 1);
      } else if (platform === 'win32') {
        fonts = out.split('\n').map(l => l.trim()).filter(l => l.length > 1 && !l.startsWith('PS') && !l.startsWith('-'));
      }
      const unique = [...new Set(fonts.map(f => f.trim()).filter(Boolean))].sort((a, b) =>
        a.localeCompare(b, undefined, { sensitivity: 'base' }));
      res.json({ fonts: unique });
    } catch { res.json({ fonts: [] }); }
  });
  proc.on('error', () => res.json({ fonts: [] }));
});

/* ══════════════════════════════════════════════════
   YT-DLP helpers
══════════════════════════════════════════════════ */
function findYtDlp() {
  const isWin = process.platform === 'win32';
  const searchDirs = [__dirname, path.join(__dirname, 'bin')];
  for (const dir of searchDirs) {
    const name = isWin ? 'yt-dlp.exe' : 'yt-dlp';
    const p = path.join(dir, name);
    if (fs.existsSync(p)) {
      if (!isWin) {
        try {
          const stat = fs.statSync(p);
          if ((stat.mode & 0o111) === 0) fs.chmodSync(p, stat.mode | 0o755);
        } catch {}
      }
      return p;
    }
  }
  return isWin ? 'yt-dlp.exe' : 'yt-dlp';
}

function ytdlpRun(args, timeout = 30000) {
  return new Promise((resolve) => {
    const bin = findYtDlp();
    let stdout = '', stderr = '';
    const proc = spawn(bin, args, { timeout });
    proc.stdout.on('data', d => stdout += d.toString());
    proc.stderr.on('data', d => stderr += d.toString());
    proc.on('close', code => resolve({ code, stdout, stderr }));
    proc.on('error', err => resolve({ code: -1, stdout, stderr: err.message }));
  });
}

/* ── Resolve YouTube video ── */
app.post('/api/resolve-youtube', async (req, res) => {
  const { url: inputUrl } = req.body;
  let videoId = '';
  try {
    if (inputUrl.includes('youtu.be/'))   videoId = inputUrl.split('youtu.be/')[1].split(/[?#]/)[0];
    else if (inputUrl.includes('v='))     videoId = inputUrl.split('v=')[1].split('&')[0];
    else if (inputUrl.includes('embed/')) videoId = inputUrl.split('embed/')[1].split(/[?#]/)[0];
    else videoId = inputUrl.trim();
  } catch { return res.json({ type: 'error', message: 'Enlace inválido.' }); }
  if (!videoId || videoId.length !== 11) return res.json({ type: 'error', message: 'ID YouTube inválido.' });

  const args = [
    '--no-playlist', '--no-warnings', '--retries', '3',
    '--extractor-retries', '3', '--socket-timeout', '15',
    '-f', 'bestaudio[ext=m4a]/bestaudio[ext=webm][acodec=opus]/bestaudio[ext=webm]/bestaudio',
    '--print', '%(title)s|||%(uploader)s|||%(thumbnail)s|||%(url)s',
    `https://www.youtube.com/watch?v=${videoId}`
  ];
  const { code, stdout, stderr } = await ytdlpRun(args);
  if (code !== 0) {
    if (stderr.includes('unavailable') || stderr.includes('not available'))
      return res.json({ type: 'error', message: 'Vídeo no disponible.' });
    if (code === 127 || stderr.includes('not found') || stderr.includes('No such file'))
      return res.json({ type: 'error', message: 'yt-dlp no encontrado. Instálalo con: pip install yt-dlp' });
    return res.json({ type: 'error', message: `Error yt-dlp: ${stderr.slice(0, 180)}` });
  }
  const line = stdout.trim().split('\n').find(l => l.includes('|||'));
  if (!line) return res.json({ type: 'error', message: 'Respuesta yt-dlp incompleta.' });
  const parts = line.split('|||');
  if (parts.length < 4) return res.json({ type: 'error', message: 'Respuesta yt-dlp incompleta.' });
  const [title, artist, thumbnail, streamUrl] = parts;
  if (!streamUrl?.startsWith('http')) return res.json({ type: 'error', message: 'No se obtuvo URL de stream.' });
  const proxyUrl = `http://${req.hostname}:${PORT}/stream?url=${encodeURIComponent(streamUrl)}`;
  res.json({ type: 'success', videoId, title, artist, thumbnail, streamUrl: proxyUrl });
});

/* ── Search YouTube ── */
app.post('/api/search-youtube', async (req, res) => {
  const { query } = req.body;
  const { code, stdout, stderr } = await ytdlpRun([
    '--no-playlist', '--no-warnings', '--flat-playlist',
    '--print', '%(id)s|%(title)s|%(uploader)s|%(duration)s|%(thumbnail)s',
    `ytsearch15:${query}`
  ]);
  if (code !== 0) {
    if (code === 127 || stderr.includes('not found'))
      return res.json({ type: 'error', message: 'yt-dlp no encontrado.' });
    return res.json({ type: 'error', message: `Error: ${stderr.slice(0, 180)}` });
  }
  const results = stdout.trim().split('\n').filter(Boolean).map(line => {
    const parts = line.split('|');
    if (parts.length < 4) return null;
    const [id, title, uploader, duration, thumbnail] = parts;
    const dur = parseInt(duration) || 0;
    const mins = Math.floor(dur / 60);
    const secs = String(dur % 60).padStart(2, '0');
    return { id, title, uploader, duration: dur > 0 ? `${mins}:${secs}` : '—', thumbnail };
  }).filter(Boolean);
  res.json({ type: 'success', results });
});

/* ── Resolve YouTube Playlist ── */
app.post('/api/resolve-youtube-playlist', async (req, res) => {
  const { url: playlistUrl } = req.body;
  let playlistId = null;
  try { playlistId = new URL(playlistUrl).searchParams.get('list'); } catch {}
  const targetUrl = playlistId
    ? `https://www.youtube.com/playlist?list=${playlistId}`
    : playlistUrl;

  const { code, stdout, stderr } = await ytdlpRun([
    '--yes-playlist', '--no-warnings', '--flat-playlist',
    '--print', '%(id)s|||%(title)s|||%(uploader)s|||%(thumbnail)s|||%(duration)s',
    targetUrl
  ], 120000);

  if (code !== 0) {
    if (code === 127 || stderr.includes('not found'))
      return res.json({ type: 'error', message: 'yt-dlp no encontrado.' });
    return res.json({ type: 'error', message: `Error yt-dlp: ${stderr.slice(0, 200)}` });
  }
  const lines = stdout.trim().split('\n').filter(l => l.includes('|||'));
  if (!lines.length) return res.json({ type: 'error', message: 'No se encontraron vídeos.' });

  let playlistTitle = 'Playlist de YouTube';
  const titleMatch = stderr.match(/\[download\] Downloading playlist: (.+)/);
  if (titleMatch) playlistTitle = titleMatch[1].trim();

  const videos = lines.map(line => {
    const [id, title, uploader, thumbnail, durationRaw] = line.split('|||');
    return { id: id?.trim(), title: title?.trim() || 'Sin título', uploader: uploader?.trim() || '', thumbnail: thumbnail?.trim() || '', duration: parseInt(durationRaw) || 0 };
  }).filter(v => v.id && v.id.length === 11);

  res.json({ type: 'success', playlistTitle, playlistId: playlistId || 'yt-pl', videos });
});

/* ── Resolve Spotify → YouTube ── */
app.post('/api/resolve-spotify-to-youtube', async (req, res) => {
  const { title, artist } = req.body;
  const cleanTitle = title.replace(/\s*[\(\[](feat\.|ft\.|with\s|prod\.|remix|version|remastered|explicit)[^\)\]]*[\)\]]/gi, '').trim();
  const primaryArtist = (artist || '').split(/[,&\/]/)[0].trim();
  const queries = [
    `${primaryArtist} - ${cleanTitle} audio`,
    `${primaryArtist} ${cleanTitle}`,
    `${artist} ${title}`,
  ];

  for (const query of queries) {
    const { code, stdout } = await ytdlpRun([
      '--no-playlist', '--no-warnings', '--flat-playlist',
      '--print', '%(id)s|%(title)s|%(uploader)s|%(duration)s',
      `ytsearch5:${query}`,
    ], 20000);
    if (code !== 0) continue;
    const results = stdout.trim().split('\n').filter(Boolean).map(line => {
      const parts = line.split('|');
      if (parts.length < 3) return null;
      const [id, t, u, dur] = parts;
      return { id: id?.trim(), title: t?.trim() || '', uploader: u?.trim() || '', duration: parseInt(dur) || 0 };
    }).filter(r => r && r.id && r.id.length === 11);
    if (!results.length) continue;

    const titleLow = cleanTitle.toLowerCase(), artistLow = primaryArtist.toLowerCase();
    const allArtLow = (artist || '').toLowerCase();
    let best = null, bestScore = -Infinity;
    for (const r of results) {
      const rt = r.title.toLowerCase(), ru = r.uploader.toLowerCase();
      let score = 0;
      if (rt.includes(titleLow)) score += 4; else if (rt.includes(title.toLowerCase())) score += 3;
      if (rt.includes(artistLow) || ru.includes(artistLow)) score += 3;
      allArtLow.split(/[,&\/]/).forEach(a => { const ac = a.trim(); if (ac && (rt.includes(ac) || ru.includes(ac))) score += 1; });
      if (rt.includes('cover') && !title.toLowerCase().includes('cover')) score -= 3;
      if (rt.includes('karaoke')) score -= 5;
      if (rt.includes('tutorial')) score -= 5;
      if (ru.includes('vevo') || ru.includes('oficial') || ru.includes('official')) score += 2;
      if (ru.includes(artistLow)) score += 2;
      if (score > bestScore) { bestScore = score; best = r; }
    }
    if (best) return res.json({ type: 'success', videoId: best.id });
  }
  res.json({ type: 'error', message: 'No encontrado en YouTube' });
});

/* ── Search Spotify (via Deezer) ── */
app.post('/api/search-spotify', async (req, res) => {
  const { query } = req.body;
  if (!query?.trim()) return res.json({ type: 'error', message: 'Búsqueda vacía.' });
  try {
    const r = await fetchUrl(`https://api.deezer.com/search?q=${encodeURIComponent(query.trim())}&limit=20&output=json`);
    if (r.status !== 200) return res.json({ type: 'error', message: `Error de búsqueda (${r.status}).` });
    const data = JSON.parse(r.body);
    const items = data.data || [];
    const tracks = items.map(t => ({
      id: String(t.id || ''), title: t.title || 'Sin título',
      artist: t.artist?.name || 'Artista desconocido', album: t.album?.title || '',
      duration: t.duration || 0, cover: t.album?.cover_medium || t.album?.cover || '',
      previewUrl: t.preview || null, spotifyUrl: t.link || '',
      explicit: t.explicit_lyrics || false, popularity: t.rank || 0,
    })).filter(t => t.id);
    res.json({ type: 'success', results: tracks });
  } catch (e) { res.json({ type: 'error', message: `Error: ${e.message}` }); }
});

/* ── Import Spotify Playlist ── */
app.post('/api/import-spotify-playlist', async (req, res) => {
  const { id: playlistId } = req.body;
  const playlistUrl = `https://open.spotify.com/playlist/${playlistId}`;
  const scriptName = 'spotify_scraper_helper.py';
  const scriptPath = [__dirname, path.join(__dirname, '..')]
    .map(d => path.join(d, scriptName))
    .find(p => fs.existsSync(p)) || path.join(__dirname, scriptName);

  const result = await new Promise((resolve) => {
    const spawnEnv = { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' };
    const proc = spawn('python3', [scriptPath, playlistUrl], { timeout: 60000, env: spawnEnv });
    const chunks = [], errChunks = [];
    proc.stdout.on('data', c => chunks.push(c));
    proc.stderr.on('data', c => errChunks.push(c));
    proc.on('close', (code) => {
      const out = Buffer.concat(chunks).toString().trim();
      const err = Buffer.concat(errChunks).toString().trim();
      if (code !== 0 || !out) return resolve({ ok: false, error: err || `Exit code ${code}` });
      try {
        const jsonLine = out.split('\n').find(l => l.trimStart().startsWith('{'));
        if (!jsonLine) throw new Error('No JSON found');
        resolve({ ok: true, data: JSON.parse(jsonLine) });
      } catch (e) { resolve({ ok: false, error: 'JSON parse error: ' + out.slice(0, 300) }); }
    });
    proc.on('error', (e) => resolve({ ok: false, error: e.message }));
  });

  if (!result.ok) return res.json({ type: 'error', message: `Error al importar: ${result.error}` });
  const { playlistTitle, tracks: spTracks } = result.data;
  if (!spTracks?.length) return res.json({ type: 'error', message: 'Playlist vacía.' });

  // Enriquecer con Deezer si falta cover/duración
  const resolved = [];
  for (const sp of spTracks) {
    if (sp.cover && sp.duration) { resolved.push(sp); continue; }
    try {
      const primaryArtist = (sp.artist || '').split(/[,&]/)[0].trim();
      const q = primaryArtist ? `artist:"${primaryArtist}" track:"${sp.title}"` : `track:"${sp.title}"`;
      const sr = await fetchUrlJson(`https://api.deezer.com/search?q=${encodeURIComponent(q)}&limit=5`);
      if (sr.ok && sr.data?.data?.length) {
        const best = sr.data.data[0];
        resolved.push({ ...sp, album: sp.album || best.album?.title || '', duration: sp.duration || best.duration || 0, cover: sp.cover || best.album?.cover_medium || '' });
      } else resolved.push(sp);
    } catch { resolved.push(sp); }
  }
  res.json({ type: 'success', playlistTitle, tracks: resolved });
});

/* ── Fetch image as base64 ── */
app.post('/api/fetch-image-base64', async (req, res) => {
  const { url } = req.body;
  try {
    const result = await new Promise((resolve) => {
      const client = url.startsWith('https') ? https : http;
      const fetch = (targetUrl, depth = 0) => {
        if (depth > 3) return resolve(null);
        client.get(targetUrl, { timeout: 8000 }, (r) => {
          if ([301, 302].includes(r.statusCode)) return fetch(r.headers.location, depth + 1);
          const chunks = [];
          r.on('data', c => chunks.push(c));
          r.on('end', () => {
            const buf = Buffer.concat(chunks);
            const mime = r.headers['content-type'] || 'image/jpeg';
            resolve(`data:${mime};base64,${buf.toString('base64')}`);
          });
        }).on('error', () => resolve(null));
      };
      fetch(url);
    });
    res.json({ dataUrl: result });
  } catch { res.json({ dataUrl: null }); }
});

/* ── Fetch Lyrics ── */
app.post('/api/fetch-lyrics', async (req, res) => {
  const { title, artist, romaji } = req.body;
  const cleanTitle  = (title||'').replace(/\(.*?\)/g,'').replace(/\[.*?\]/g,'').replace(/ft\.?.*/i,'').trim();
  const cleanArtist = (artist||'').replace(/\s*ft\.?.*/i,'').split(',')[0].split('&')[0].trim();

  async function scrapeGeniusPage(url) {
    try {
      const page = await fetchUrl(url);
      if (page.status !== 200) return null;
      const containers = [];
      const regex = /data-lyrics-container="true"[^>]*>([\s\S]*?)<\/div>/g;
      let m; while ((m = regex.exec(page.body)) !== null) containers.push(m[1]);
      if (!containers.length) return null;
      let raw = containers.join('\n').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]+>/g,'');
      raw = raw.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#x27;/gi,"'").replace(/&#39;/g,"'").trim();
      return raw.length > 20 ? raw : null;
    } catch { return null; }
  }

  async function searchGeniusAll(query, maxHits = 5) {
    const results = [];
    try {
      const r = await fetchUrl(`https://genius.com/api/search/multi?per_page=${maxHits}&q=${encodeURIComponent(query)}`);
      if (r.status !== 200) return results;
      const data = JSON.parse(r.body);
      const hits = data?.response?.sections?.find(s => s.type === 'song')?.hits || [];
      for (const h of hits.slice(0, maxHits)) {
        if (!h?.result?.url) continue;
        const lyr = await scrapeGeniusPage(h.result.url);
        if (lyr) results.push({ label: `${h.result.title} — ${h.result.primary_artist?.name || ''}`.trim(), url: h.result.url, lyrics: lyr, synced: null, source: 'Genius' });
      }
    } catch {}
    return results;
  }

  const allResults = [];

  // 1) LRCLib
  try {
    const r = await fetchUrl(`https://lrclib.net/api/search?track_name=${encodeURIComponent(cleanTitle)}&artist_name=${encodeURIComponent(cleanArtist)}`);
    if (r.status === 200) {
      const list = JSON.parse(r.body);
      for (const item of list.slice(0, 3)) {
        if (item.syncedLyrics?.length > 20)
          allResults.push({ label:`${item.trackName} — ${item.artistName}`, lyrics: item.plainLyrics || item.syncedLyrics, synced: item.syncedLyrics, source:'LRCLib (sync)' });
        else if (item.plainLyrics?.length > 20)
          allResults.push({ label:`${item.trackName} — ${item.artistName}`, lyrics: item.plainLyrics, synced: null, source:'LRCLib' });
      }
    }
  } catch {}

  // 2) Genius
  const gHits = await searchGeniusAll(`${cleanTitle} ${cleanArtist}`, 3);
  allResults.push(...gHits);

  // 3) lyrics.ovh
  try {
    const r = await fetchUrl(`https://api.lyrics.ovh/v1/${encodeURIComponent(cleanArtist)}/${encodeURIComponent(cleanTitle)}`);
    if (r.status === 200) {
      const data = JSON.parse(r.body);
      if (data.lyrics?.length > 20) allResults.push({ label:`${cleanTitle} — lyrics.ovh`, lyrics: data.lyrics, synced: null, source:'lyrics.ovh' });
    }
  } catch {}

  if (!allResults.length) return res.json({ found: false });
  res.json({ found: true, multiple: allResults.length > 1, results: allResults, lyrics: allResults[0].lyrics, synced: allResults[0].synced || null, source: allResults[0].source });
});

/* ── Downloads ── */
const activeDownloads = new Map();
// SSE clients for download progress
const sseClients = new Set();

app.get('/api/download-progress-stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();
  sseClients.add(res);
  req.on('close', () => sseClients.delete(res));
});

function sendDownloadProgress(data) {
  const msg = `data: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) {
    try { client.write(msg); } catch {}
  }
}

app.get('/api/download-default-folder', (req, res) => {
  try { res.json({ folder: os.homedir() + '/Music' }); }
  catch { res.json({ folder: os.homedir() }); }
});

app.post('/api/download-youtube', async (req, res) => {
  const { id, videoId, ytUrl, title, artist, outDir, format } = req.body;
  const ytdlpBin = findYtDlp();
  const url = ytUrl || `https://www.youtube.com/watch?v=${videoId}`;
  const safeTitle = (title || 'audio').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').slice(0, 120);
  const safeArtist = (artist || '').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').slice(0, 80);
  const baseName = safeArtist ? `${safeArtist} - ${safeTitle}` : safeTitle;
  const targetDir = outDir || path.join(os.homedir(), 'Music', 'NofufAudio');
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

  const fmt = (format || 'mp3').toLowerCase();
  const useExtract = ['mp3','m4a','opus','wav','flac','aac'].includes(fmt);
  const args = ['--no-playlist', '--no-warnings', '-o', path.join(targetDir, baseName + '.%(ext)s'), '--newline', '--progress'];
  if (useExtract) args.push('-x', '--audio-format', fmt, '--audio-quality', '0');
  else args.push('-f', 'bestaudio');
  args.push(url);

  sendDownloadProgress({ id, status: 'starting', percent: 0 });
  const proc = spawn(ytdlpBin, args);
  activeDownloads.set(id, proc);
  let stderr = '';

  const handle = (chunk) => {
    const txt = chunk.toString();
    txt.split(/\r?\n/).forEach(line => {
      const m = line.match(/\[download\]\s+([\d.]+)%/);
      if (m) {
        const speedM = line.match(/at\s+([\d.]+\w+\/s)/);
        const etaM = line.match(/ETA\s+([\d:]+)/);
        sendDownloadProgress({ id, status: 'downloading', percent: parseFloat(m[1]), speed: speedM?.[1], eta: etaM?.[1] });
      } else if (line.includes('[ExtractAudio]') || line.includes('Destination:')) {
        sendDownloadProgress({ id, status: 'processing', percent: 99, message: line.slice(0, 120) });
      }
    });
  };
  proc.stdout.on('data', handle);
  proc.stderr.on('data', d => { stderr += d.toString(); handle(d); });
  proc.on('close', code => {
    activeDownloads.delete(id);
    if (code === 0) sendDownloadProgress({ id, status: 'done', percent: 100, path: targetDir });
    else sendDownloadProgress({ id, status: 'error', percent: 0, error: stderr.slice(0, 200) || `Código ${code}` });
  });
  proc.on('error', err => { activeDownloads.delete(id); sendDownloadProgress({ id, status: 'error', percent: 0, error: err.message }); });

  res.json({ ok: true, message: 'Descarga iniciada, progreso via SSE' });
});

app.post('/api/download-cancel', (req, res) => {
  const { id } = req.body;
  const proc = activeDownloads.get(id);
  if (proc) { try { proc.kill(); } catch {} activeDownloads.delete(id); return res.json({ ok: true }); }
  res.json({ ok: false });
});

/* ── Open External URL (en móvil simplemente redirige) ── */
app.post('/api/open-external-url', (req, res) => {
  res.json({ ok: true, url: req.body.url });
});

/* ── Read file metadata (solo si se puede acceder al archivo local — no disponible en móvil) ── */
app.post('/api/read-file-metadata', async (req, res) => {
  res.json({ title: 'Unknown', artist: 'Unknown', duration: 0, cover: null });
});

/* ══════════════════════════════════════════════════
   Generic HTTP helpers
══════════════════════════════════════════════════ */
function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const doFetch = (targetUrl, depth = 0) => {
      if (depth > 5) { reject(new Error('Too many redirects')); return; }
      try {
        const req = client.get(targetUrl, { timeout: 10000, headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
          if ([301,302,303,307,308].includes(res.statusCode) && res.headers.location) { doFetch(res.headers.location, depth + 1); return; }
          let data = '';
          res.on('data', c => data += c.toString());
          res.on('end', () => resolve({ status: res.statusCode, body: data, headers: res.headers }));
          res.on('error', reject);
        });
        req.on('error', reject);
        req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
      } catch (e) { reject(e); }
    };
    doFetch(url);
  });
}

function fetchUrlJson(url) {
  return new Promise((resolve) => {
    const client = url.startsWith('https') ? https : http;
    const doFetch = (targetUrl, depth = 0) => {
      if (depth > 5) { resolve({ ok: false }); return; }
      try {
        const req = client.get(targetUrl, { timeout: 12000, headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' } }, (res) => {
          if ([301,302,303,307,308].includes(res.statusCode) && res.headers.location) { doFetch(res.headers.location, depth + 1); return; }
          const chunks = [];
          res.on('data', c => chunks.push(c));
          res.on('end', () => {
            try { resolve({ ok: res.statusCode === 200, data: JSON.parse(Buffer.concat(chunks).toString('utf-8')) }); }
            catch { resolve({ ok: false }); }
          });
          res.on('error', () => resolve({ ok: false }));
        });
        req.on('error', () => resolve({ ok: false }));
        req.on('timeout', () => { req.destroy(); resolve({ ok: false }); });
      } catch { resolve({ ok: false }); }
    };
    doFetch(url);
  });
}

/* ── Catch-all: serve index.html para SPA ── */
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

/* ── Start ── */
app.listen(PORT, '0.0.0.0', () => {
  const ifaces = os.networkInterfaces();
  let localIp = 'localhost';
  for (const iface of Object.values(ifaces)) {
    for (const info of iface) {
      if (info.family === 'IPv4' && !info.internal) { localIp = info.address; break; }
    }
  }
  console.log(`\n╔══════════════════════════════════════════╗`);
  console.log(`║  NofufAudio PWA — servidor iniciado       ║`);
  console.log(`╠══════════════════════════════════════════╣`);
  console.log(`║  Local:   http://localhost:${PORT}           ║`);
  console.log(`║  Red:     http://${localIp}:${PORT}     ║`);
  console.log(`║                                          ║`);
  console.log(`║  Abre la URL de Red en Android para      ║`);
  console.log(`║  instalarla como PWA (Add to Home Screen)║`);
  console.log(`╚══════════════════════════════════════════╝\n`);
});
