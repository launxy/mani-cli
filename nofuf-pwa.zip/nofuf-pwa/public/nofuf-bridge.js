/* ═══════════════════════════════════════════════
   NOFUFAUDIO — nofuf-bridge.js
   Reemplaza window.nofuf (Electron IPC) con llamadas HTTP
   al servidor Express. Se carga antes de app.js.
═══════════════════════════════════════════════ */

(function () {
  const BASE = window.location.origin; // http://<ip>:3000

  async function api(method, endpoint, body) {
    const opts = {
      method,
      headers: { 'Content-Type': 'application/json' },
    };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res = await fetch(`${BASE}${endpoint}`, opts);
    return res.json();
  }

  /* ── SSE for download progress ── */
  let _downloadProgressCbs = [];
  let _sseSource = null;
  let _sseFailed = false;

  function ensureSSE() {
    if (_sseSource || _sseFailed) return;
    try {
      _sseSource = new EventSource(`${BASE}/api/download-progress-stream`);
      _sseSource.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          _downloadProgressCbs.forEach(cb => cb(data));
        } catch {}
      };
      _sseSource.onerror = () => {
        // Fallo silencioso — el endpoint puede no estar disponible
        _sseFailed = true;
        if (_sseSource) { _sseSource.close(); _sseSource = null; }
      };
    } catch (err) {
      _sseFailed = true;
    }
  }

  /* ═══════════════════════════════════════════
     window.nofuf — API compatible con Electron
  ═══════════════════════════════════════════ */
  window.nofuf = {
    platform: 'pwa',

    /* ── Window controls (no-ops en PWA) ── */
    minimize: () => {},
    maximize: () => {},
    close:    () => window.history.back(),
    quit:     () => {},
    show:     () => {},
    reload:   () => window.location.reload(),

    /* ── Config ── */
    configDir: async () => {
      const r = await api('GET', '/api/config-dir');
      return r.dir;
    },
    configRead: async (name) => {
      const r = await api('GET', `/api/config-read/${encodeURIComponent(name)}`);
      return r.content;
    },
    configWrite: async (name, content) => {
      return api('POST', '/api/config-write', { name, content });
    },
    configOpenFolder: async () => {},
    exportConfigFile: async (defaultName, content) => {
      const blob = new Blob([content], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = defaultName || 'nofufaudio-config.json';
      a.click(); URL.revokeObjectURL(url);
      return { ok: true };
    },
    importConfigFile: async () => {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = '.json,.txt';
        input.onchange = async (e) => {
          const file = e.target.files[0];
          if (!file) return resolve(null);
          const content = await file.text();
          resolve({ path: file.name, content });
        };
        input.click();
      });
    },
    openExternalUrl: async (url) => {
      window.open(url, '_blank');
      return { ok: true };
    },

    /* ── System fonts ── */
    getSystemFonts: async () => {
      const r = await api('GET', '/api/system-fonts');
      return r.fonts || [];
    },

    /* ── File dialogs (PWA usa file picker nativo) ── */
    openFileDialog: async () => {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file';
        input.multiple = true;
        input.accept = '.mp3,.flac,.wav,.ogg,.m4a,.aac,.opus';
        input.onchange = (e) => {
          const files = Array.from(e.target.files);
          window._nofufFiles = window._nofufFiles || {};
          const urls = files.map(f => {
            const url = URL.createObjectURL(f);
            window._nofufFiles[url] = f;
            return url;
          });
          resolve(urls);
        };
        input.click();
      });
    },
    openFolderDialog: async () => {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file';
        input.multiple = true;
        input.accept = '.mp3,.flac,.wav,.ogg,.m4a,.aac,.opus';
        input.setAttribute('webkitdirectory', '');
        input.onchange = (e) => {
          window._nofufFiles = window._nofufFiles || {};
          const urls = Array.from(e.target.files).map(f => {
            const url = URL.createObjectURL(f);
            window._nofufFiles[url] = f;
            return url;
          });
          resolve(urls);
        };
        input.click();
      });
    },
    openImageDialog: async () => {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = 'image/*';
        input.onchange = (e) => {
          const file = e.target.files[0];
          if (!file) return resolve(null);
          const reader = new FileReader();
          reader.onload = (ev) => resolve(ev.target.result);
          reader.readAsDataURL(file);
        };
        input.click();
      });
    },

    /* ── File metadata ── */
    readFileMetadata: async (filePath) => {
      const file = window._nofufFiles?.[filePath];
      if (file) {
        return {
          title: file.name.replace(/\.[^.]+$/, ''),
          artist: 'Artista Desconocido',
          duration: 0,
          cover: null,
        };
      }
      const r = await api('POST', '/api/read-file-metadata', { filePath });
      return r;
    },

    pathToFileUrl: (p) => p,

    /* ── YouTube ── */
    resolveYouTube: async (url) => {
      return api('POST', '/api/resolve-youtube', { url });
    },
    resolveYouTubePlaylist: async (url) => {
      return api('POST', '/api/resolve-youtube-playlist', { url });
    },
    searchYouTube: async (query) => {
      return api('POST', '/api/search-youtube', { query });
    },

    /* ── Spotify ── */
    searchSpotify: async (query) => {
      return api('POST', '/api/search-spotify', { query });
    },
    importSpotifyPlaylist: async (id) => {
      return api('POST', '/api/import-spotify-playlist', { id });
    },
    resolveSpotifyToYouTube: async (title, artist) => {
      return api('POST', '/api/resolve-spotify-to-youtube', { title, artist });
    },

    /* ── Misc ── */
    fetchImageBase64: async (url) => {
      const r = await api('POST', '/api/fetch-image-base64', { url });
      return r.dataUrl;
    },
    fetchLyricsMain: async (opts) => {
      return api('POST', '/api/fetch-lyrics', opts);
    },
    streamProxyPort: async () => {
      return parseInt(window.location.port) || 3000;
    },

    /* ── Downloads ── */
    downloadPickFolder: async () => {
      const r = await api('GET', '/api/download-default-folder');
      return r.folder || null;
    },
    downloadDefaultFolder: async () => {
      const r = await api('GET', '/api/download-default-folder');
      return r.folder || null;
    },
    downloadYouTube: async (opts) => {
      return api('POST', '/api/download-youtube', opts);
    },
    downloadLocalFile: async (opts) => {
      return { ok: false, error: 'No disponible en PWA' };
    },
    downloadCancel: async (id) => {
      return api('POST', '/api/download-cancel', { id });
    },
    onDownloadProgress: (cb) => {
      ensureSSE();
      _downloadProgressCbs.push(cb);
      return () => {
        _downloadProgressCbs = _downloadProgressCbs.filter(f => f !== cb);
      };
    },

    /* ── Save before hide ── */
    onSaveBeforeHide: (cb) => {
      window.addEventListener('beforeunload', cb);
      window.addEventListener('pagehide', cb);
      return () => {
        window.removeEventListener('beforeunload', cb);
        window.removeEventListener('pagehide', cb);
      };
    },
  };

  console.log('[nofuf-bridge] API PWA lista →', BASE);
})();
